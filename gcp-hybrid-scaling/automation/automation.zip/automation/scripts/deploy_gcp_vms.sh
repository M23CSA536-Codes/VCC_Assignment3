#!/bin/bash
cd terraform/gcp/
terraform init
terraform apply -auto-approve